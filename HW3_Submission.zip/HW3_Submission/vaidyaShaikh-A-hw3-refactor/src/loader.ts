import * as main from "./main";

window.onload = () => {
  console.log("window.onload called");
  main.init();
};
